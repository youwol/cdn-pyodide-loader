((typeof self !== 'undefined' ? self : this)["webpackChunkpyodide_APIv021"] = (typeof self !== 'undefined' ? self : this)["webpackChunkpyodide_APIv021"] || []).push([["_c01b"],{

/***/ "?c01b":
/*!*****************************!*\
  !*** fs/promises (ignored) ***!
  \*****************************/
/***/ (() => {

/* (ignored) */

/***/ })

}]);
//# sourceMappingURL=_c01b.pyodide.js.map