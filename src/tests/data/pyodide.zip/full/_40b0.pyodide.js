((typeof self !== 'undefined' ? self : this)["webpackChunkpyodide_APIv021"] = (typeof self !== 'undefined' ? self : this)["webpackChunkpyodide_APIv021"] || []).push([["_40b0"],{

/***/ "?40b0":
/*!********************!*\
  !*** ws (ignored) ***!
  \********************/
/***/ (() => {

/* (ignored) */

/***/ })

}]);
//# sourceMappingURL=_40b0.pyodide.js.map