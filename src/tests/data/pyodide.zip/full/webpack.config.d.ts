declare const apiVersion = "021";
declare const externals: {};
declare const path: any;
declare const pkg: any;
declare const ROOT: any;
declare const DESTINATION: any;
declare const BundleAnalyzerPlugin: any;
