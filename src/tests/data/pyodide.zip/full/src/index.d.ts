import * as AllImports from "pyodide";
export * from "pyodide";
export declare function loadPyodideCustom(args: any): Promise<AllImports.PyodideInterface>;
