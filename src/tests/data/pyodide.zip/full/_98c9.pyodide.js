((typeof self !== 'undefined' ? self : this)["webpackChunkpyodide_APIv021"] = (typeof self !== 'undefined' ? self : this)["webpackChunkpyodide_APIv021"] || []).push([["_98c9"],{

/***/ "?98c9":
/*!*******************************!*\
  !*** child_process (ignored) ***!
  \*******************************/
/***/ (() => {

/* (ignored) */

/***/ })

}]);
//# sourceMappingURL=_98c9.pyodide.js.map