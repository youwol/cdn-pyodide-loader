((typeof self !== 'undefined' ? self : this)["webpackChunkpyodide_APIv021"] = (typeof self !== 'undefined' ? self : this)["webpackChunkpyodide_APIv021"] || []).push([["_9c57"],{

/***/ "?9c57":
/*!********************!*\
  !*** vm (ignored) ***!
  \********************/
/***/ (() => {

/* (ignored) */

/***/ })

}]);
//# sourceMappingURL=_9c57.pyodide.js.map