((typeof self !== 'undefined' ? self : this)["webpackChunkpyodide_APIv021"] = (typeof self !== 'undefined' ? self : this)["webpackChunkpyodide_APIv021"] || []).push([["_2078"],{

/***/ "?2078":
/*!**********************!*\
  !*** path (ignored) ***!
  \**********************/
/***/ (() => {

/* (ignored) */

/***/ })

}]);
//# sourceMappingURL=_2078.pyodide.js.map